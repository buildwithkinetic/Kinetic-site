"use client"

import { useEffect, useState, useRef, type MouseEvent } from "react"
import { motion, useInView, useScroll, useTransform, useMotionValue, useSpring, type Variants } from "framer-motion"
import {
  Globe, Target, Zap, LayoutDashboard, TrendingUp,
  ChevronRight, Menu, X as XIcon, Mail, MapPin,
  ArrowUpRight, Check, Sparkles,
} from "lucide-react"

// ─── Design Tokens ────────────────────────────────────────────────────────────
// Warm cream / ivory premium palette
// BG:      #F5F0E8  (warm ivory)
// Surface: #FFFFFF
// Text:    #0F0E0C  (warm near-black)
// Muted:   #6B6560
// Accent:  #C8440A  (rich burnt orange)
// Gold:    #B08D57  (warm gold)
// Border:  rgba(15,14,12,0.08)

// ─── Animation Variants ───────────────────────────────────────────────────────
const fadeUp: Variants = {
  hidden: { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
}
const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.6 } },
}
const stagger: Variants = {
  visible: { transition: { staggerChildren: 0.1 } },
}
const slideLeft: Variants = {
  hidden: { opacity: 0, x: -40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
}

// ─── Section Wrapper ──────────────────────────────────────────────────────────
function Section({ children, className = "", id }: { children: React.ReactNode; className?: string; id?: string }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })
  return (
    <motion.section ref={ref} id={id} initial="hidden" animate={isInView ? "visible" : "hidden"} variants={stagger} className={className}>
      {children}
    </motion.section>
  )
}

// ─── Magnetic Button ──────────────────────────────────────────────────────────
function MagneticButton({ children, className = "", href, onClick }: {
  children: React.ReactNode; className?: string; href?: string; onClick?: () => void
}) {
  const ref = useRef<HTMLAnchorElement>(null)
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const springX = useSpring(x, { stiffness: 300, damping: 30 })
  const springY = useSpring(y, { stiffness: 300, damping: 30 })

  const handleMouseMove = (e: MouseEvent<HTMLAnchorElement>) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    x.set((e.clientX - rect.left - rect.width / 2) * 0.35)
    y.set((e.clientY - rect.top - rect.height / 2) * 0.35)
  }
  const handleMouseLeave = () => { x.set(0); y.set(0) }

  return (
    <motion.a
      ref={ref}
      href={href}
      onClick={onClick}
      style={{ x: springX, y: springY }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={className}
    >
      {children}
    </motion.a>
  )
}

// ─── Navbar ───────────────────────────────────────────────────────────────────
function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { scrollYProgress } = useScroll()
  const progressWidth = useTransform(scrollYProgress, [0, 1], ["0%", "100%"])

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener("scroll", handler)
    return () => window.removeEventListener("scroll", handler)
  }, [])

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "bg-[#F5F0E8]/90 backdrop-blur-xl shadow-sm shadow-black/5" : "bg-transparent"}`}>
      <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        <a href="#" className="font-[family-name:var(--font-playfair)] text-2xl font-black text-[#0F0E0C] tracking-tight">
          KINETIC<span className="text-[#C8440A]">.</span>
        </a>

        <div className="hidden md:flex items-center gap-10">
          {["Services", "Portfolio", "About", "Contact"].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`}
              className="text-sm font-medium text-[#6B6560] hover:text-[#0F0E0C] transition-colors duration-200 relative group">
              {item}
              <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-[#C8440A] group-hover:w-full transition-all duration-300" />
            </a>
          ))}
        </div>

        <MagneticButton
          href="#contact"
          className="hidden md:inline-flex items-center gap-2 px-6 py-2.5 bg-[#0F0E0C] text-[#F5F0E8] text-sm font-semibold rounded-full hover:bg-[#C8440A] transition-colors duration-300 group"
        >
          Book a Call
          <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
        </MagneticButton>

        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-[#0F0E0C]" aria-label="Toggle menu">
          {isOpen ? <XIcon size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isOpen && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-[#F5F0E8]/98 border-t border-black/8 px-6 py-6 shadow-lg">
          <div className="flex flex-col gap-5">
            {["Services", "Portfolio", "About", "Contact"].map(item => (
              <a key={item} href={`#${item.toLowerCase()}`}
                className="text-[#0F0E0C] font-medium hover:text-[#C8440A] transition-colors"
                onClick={() => setIsOpen(false)}>{item}</a>
            ))}
            <a href="#contact" onClick={() => setIsOpen(false)}
              className="px-5 py-3 bg-[#0F0E0C] text-[#F5F0E8] text-sm font-semibold rounded-full text-center hover:bg-[#C8440A] transition-colors">
              Book a Call
            </a>
          </div>
        </motion.div>
      )}

      <motion.div className="absolute bottom-0 left-0 h-[1.5px] bg-[#C8440A]" style={{ width: progressWidth }} />
    </nav>
  )
}

// ─── Lead Pipeline Visual ─────────────────────────────────────────────────────
const STAGES = ["New", "Contacted", "Proposal", "Closed"] as const
type Stage = typeof STAGES[number]

const STAGE_COLORS: Record<Stage, { bg: string; text: string; dot: string }> = {
  New:       { bg: "bg-sky-50",     text: "text-sky-700",     dot: "bg-sky-400" },
  Contacted: { bg: "bg-amber-50",   text: "text-amber-700",   dot: "bg-amber-400" },
  Proposal:  { bg: "bg-violet-50",  text: "text-violet-700",  dot: "bg-violet-400" },
  Closed:    { bg: "bg-emerald-50", text: "text-emerald-700", dot: "bg-emerald-500" },
}

const LEAD_ICONS = ["🛍️", "📱", "🏗️", "🎓", "💼", "🌿", "🏥", "✈️"]

interface Lead { id: number; icon: string; label: string; stage: Stage; age: string }

const INITIAL_LEADS: Lead[] = [
  { id: 1, icon: "📱", label: "SaaS Product",    stage: "New",       age: "just now" },
  { id: 2, icon: "🏗️", label: "Real Estate Co.", stage: "Contacted", age: "2h ago" },
  { id: 3, icon: "🎓", label: "EdTech Startup",  stage: "Contacted", age: "5h ago" },
  { id: 4, icon: "💼", label: "Consulting Firm",  stage: "Proposal",  age: "1d ago" },
  { id: 5, icon: "🌿", label: "D2C Brand",        stage: "Proposal",  age: "2d ago" },
  { id: 6, icon: "🏥", label: "Health Clinic",    stage: "Closed",    age: "3d ago" },
]

function DashboardWidget() {
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS)
  const [movingId, setMovingId] = useState<number | null>(null)
  const [notif, setNotif] = useState<{ label: string; stage: Stage } | null>(null)
  const [conversionPct, setConversionPct] = useState(0)
  const nextId = useRef(7)

  // Animate conversion bar on mount
  useEffect(() => {
    const t = setTimeout(() => setConversionPct(68), 600)
    return () => clearTimeout(t)
  }, [])

  // Every 3s: advance the earliest non-Closed lead one stage
  useEffect(() => {
    const interval = setInterval(() => {
      setLeads(prev => {
        const idx = prev.findIndex(l => l.stage !== "Closed")
        if (idx === -1) return prev
        const lead = prev[idx]
        const nextStage = STAGES[STAGES.indexOf(lead.stage) + 1] as Stage
        setMovingId(lead.id)
        setNotif({ label: lead.label, stage: nextStage })
        setTimeout(() => setMovingId(null), 700)
        setTimeout(() => setNotif(null), 2400)
        return prev.map((l, i) => i === idx ? { ...l, stage: nextStage, age: "just now" } : l)
      })
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  // Every 7s: inject a fresh lead into "New"
  useEffect(() => {
    const interval = setInterval(() => {
      const icon = LEAD_ICONS[nextId.current % LEAD_ICONS.length]
      const labels = ["Fintech App", "Agency", "E-commerce", "NGO", "Law Firm", "Media Co."]
      const label = labels[nextId.current % labels.length]
      setLeads(prev => [{ id: nextId.current++, icon, label, stage: "New", age: "just now" }, ...prev.slice(0, 7)])
    }, 7000)
    return () => clearInterval(interval)
  }, [])

  const byStage = (s: Stage) => leads.filter(l => l.stage === s)

  return (
    <div className="relative w-full max-w-[460px]">

      {/* Stage-advance notification */}
      {notif && (
        <motion.div key={notif.label + notif.stage}
          initial={{ opacity: 0, y: -10, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0 }}
          className="absolute -top-5 left-1/2 -translate-x-1/2 z-20 bg-white rounded-2xl shadow-xl shadow-black/10 border border-black/6 px-4 py-2.5 flex items-center gap-2.5 whitespace-nowrap">
          <span className={`w-2 h-2 rounded-full ${STAGE_COLORS[notif.stage].dot}`} />
          <span className="text-xs font-semibold text-[#0F0E0C]">{notif.label}</span>
          <span className="text-xs text-[#9E9890]">moved to</span>
          <span className={`text-xs font-semibold ${STAGE_COLORS[notif.stage].text}`}>{notif.stage}</span>
        </motion.div>
      )}

      {/* Main card */}
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="bg-white rounded-3xl border border-black/8 shadow-2xl shadow-black/8 overflow-hidden">

        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-black/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono text-[#9E9890] tracking-wider uppercase">Lead Pipeline · Live</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-[#9E9890] font-mono">{leads.length} leads</span>
          </div>
        </div>

        {/* Conversion bar */}
        <div className="px-5 py-4 border-b border-black/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-[#9E9890] uppercase tracking-wider">Conversion Rate</span>
            <span className="text-xs font-bold text-[#0F0E0C]">{conversionPct}%</span>
          </div>
          <div className="h-1.5 bg-[#F5F0E8] rounded-full overflow-hidden">
            <motion.div className="h-full rounded-full bg-gradient-to-r from-[#C8440A] to-amber-400"
              initial={{ width: 0 }}
              animate={{ width: `${conversionPct}%` }}
              transition={{ duration: 1.2, delay: 0.6, ease: [0.22, 1, 0.36, 1] }} />
          </div>
          <div className="flex justify-between mt-1.5">
            {STAGES.map(s => (
              <span key={s} className="text-[10px] font-mono text-[#C0BAB4]">{s}</span>
            ))}
          </div>
        </div>

        {/* Kanban columns */}
        <div className="grid grid-cols-4 divide-x divide-black/5 min-h-[220px]">
          {STAGES.map(stage => {
            const stageLeads = byStage(stage)
            const colors = STAGE_COLORS[stage]
            return (
              <div key={stage} className="p-3 flex flex-col gap-2">
                {/* Column header */}
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono text-[#9E9890] uppercase tracking-wide">{stage}</span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${colors.bg} ${colors.text}`}>
                    {stageLeads.length}
                  </span>
                </div>

                {/* Lead cards */}
                <div className="flex flex-col gap-1.5 flex-1">
                  {stageLeads.slice(0, 3).map(lead => (
                    <motion.div key={lead.id} layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{
                        opacity: 1, scale: 1,
                        boxShadow: movingId === lead.id ? "0 0 0 2px #C8440A55" : "none"
                      }}
                      transition={{ duration: 0.35 }}
                      className={`rounded-xl p-2.5 border transition-colors ${
                        movingId === lead.id
                          ? "border-[#C8440A]/40 bg-[#C8440A]/5"
                          : `border-black/5 ${colors.bg}`
                      }`}>
                      <div className="text-base leading-none mb-1">{lead.icon}</div>
                      <p className="text-[10px] font-semibold text-[#0F0E0C] leading-tight">{lead.label}</p>
                      <p className="text-[9px] text-[#9E9890] mt-0.5">{lead.age}</p>
                    </motion.div>
                  ))}
                  {stageLeads.length > 3 && (
                    <div className="text-[9px] font-mono text-[#C0BAB4] text-center py-1">
                      +{stageLeads.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Footer: automation strip */}
        <div className="px-5 py-3.5 border-t border-black/5 flex items-center gap-3 bg-[#F5F0E8]/60">
          <Zap className="w-3.5 h-3.5 text-[#C8440A] shrink-0" />
          <p className="text-xs text-[#6B6560] flex-1">
            <span className="font-semibold text-[#0F0E0C]">Auto follow-up</span> active for all Contacted leads
          </p>
          <div className="flex gap-0.5 items-end">
            {[0, 1, 2].map(i => (
              <motion.div key={i} className="w-0.5 rounded-full bg-[#C8440A]"
                animate={{ height: ["4px", "10px", "4px"] }}
                transition={{ duration: 0.7, delay: i * 0.12, repeat: Infinity }} />
            ))}
          </div>
        </div>
      </motion.div>

      {/* Floating stat */}
      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.0, duration: 0.6 }}
        className="absolute -bottom-5 -left-5 bg-[#0F0E0C] rounded-2xl px-5 py-4 shadow-xl shadow-black/25">
        <p className="text-[10px] font-mono text-[#6B6560] uppercase tracking-wider mb-1">Avg. Response</p>
        <p className="text-xl font-bold text-white">{"< 2 "}<span className="text-[#C8440A] text-xs font-mono">min</span></p>
      </motion.div>
    </div>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <Section className="min-h-screen flex items-center relative overflow-hidden pt-24 pb-16">
      {/* Grain */}
      <div className="absolute inset-0 opacity-[0.025] pointer-events-none"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`, backgroundSize: '200px' }} />

      {/* Soft radial glow */}
      <div className="absolute top-1/3 right-1/3 w-[700px] h-[700px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(200,68,10,0.06) 0%, transparent 65%)' }} />

      {/* Decorative vertical line */}
      <div className="absolute top-0 left-[52%] w-px h-full bg-gradient-to-b from-transparent via-[#C8440A]/10 to-transparent hidden lg:block" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">

          {/* Left — Copy */}
          <div>
            <motion.div variants={fadeIn}
              className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full border border-[#C8440A]/25 bg-[#C8440A]/5 mb-8">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C8440A] animate-pulse" />
              <span className="text-xs font-mono text-[#C8440A] tracking-[0.15em]">ACCEPTING NEW CLIENTS</span>
            </motion.div>

            <motion.h1 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-[2.8rem] sm:text-5xl md:text-6xl font-bold text-[#0F0E0C] mb-6 leading-[1.05]"
              style={{ letterSpacing: "-0.02em" }}>
              The operating<br />
              system for your<br />
              <em className="not-italic text-[#C8440A]">digital growth.</em>
            </motion.h1>

            <motion.p variants={fadeUp} className="text-lg text-[#6B6560] max-w-md mb-4 leading-relaxed font-light">
              We engineer websites, CRMs, and automation that convert attention into revenue.{" "}
              <span className="text-[#0F0E0C] font-medium">Not tactics — infrastructure.</span>
            </motion.p>

            <motion.p variants={fadeUp} className="text-sm text-[#9E9890] tracking-wide mb-10 font-mono">
              Built for founders who are serious about growth.
            </motion.p>

            <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-start gap-3 mb-14">
              <MagneticButton href="#contact"
                className="group flex items-center gap-3 px-7 py-3.5 bg-[#0F0E0C] text-[#F5F0E8] font-semibold rounded-full hover:bg-[#C8440A] transition-all duration-300 shadow-lg shadow-black/10 hover:shadow-[#C8440A]/25 hover:shadow-xl text-sm">
                Start Your Project
                <ArrowUpRight size={15} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </MagneticButton>
              <MagneticButton href="#portfolio"
                className="flex items-center gap-2 px-7 py-3.5 border border-[#0F0E0C]/15 text-[#0F0E0C] font-medium rounded-full hover:border-[#C8440A]/40 hover:bg-[#C8440A]/5 transition-all duration-300 text-sm">
                See Our Work <ChevronRight size={15} />
              </MagneticButton>
            </motion.div>

            {/* Stats row */}
            <motion.div variants={fadeUp} className="flex items-center gap-8 pt-8 border-t border-black/8">
              {[{ v: "100%", l: "Custom Built" }, { v: "< 30 days", l: "To Launch" }, { v: "24 hr", l: "Response" }].map(s => (
                <div key={s.l}>
                  <div className="text-xl font-bold text-[#0F0E0C] font-[family-name:var(--font-playfair)]">{s.v}</div>
                  <div className="text-xs text-[#9E9890] font-mono tracking-wide uppercase mt-0.5">{s.l}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right — Animated Dashboard */}
          <motion.div variants={fadeUp} className="flex justify-center lg:justify-end pt-8 lg:pt-0">
            <DashboardWidget />
          </motion.div>

        </div>
      </div>
    </Section>
  )
}

// ─── Problem Section ──────────────────────────────────────────────────────────
function ProblemSection() {
  return (
    <Section className="py-32 bg-[#0F0E0C] relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`, backgroundSize: '200px' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-6">The Problem</motion.span>
            <motion.h2 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-black text-white mb-8 leading-tight"
              style={{ letterSpacing: "-0.03em" }}>
              Most businesses<br />
              are <span className="italic text-[#C8440A]">invisible</span><br />
              online.
            </motion.h2>
            <motion.p variants={fadeUp} className="text-[#8B8580] text-lg leading-relaxed">
              You have a great product. But your digital presence doesn&apos;t reflect it. No system. No automation. No way to capture leads while you sleep.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {[
              { icon: "×", title: "Template websites", desc: "that look like everyone else and convert no one" },
              { icon: "×", title: "Zero automation", desc: "manually chasing every lead, losing 60% of them" },
              { icon: "×", title: "No data visibility", desc: "running blind with no CRM or pipeline tracking" },
              { icon: "×", title: "Slow launches", desc: "6-month agency timelines for a 3-week project" },
            ].map((item, i) => (
              <motion.div key={i} variants={fadeUp}
                className="group flex items-start gap-4 p-5 rounded-2xl border border-white/5 hover:border-[#C8440A]/30 hover:bg-[#C8440A]/5 transition-all duration-300 cursor-default">
                <span className="text-[#C8440A] text-xl font-black mt-0.5 group-hover:scale-110 transition-transform">{item.icon}</span>
                <div>
                  <p className="text-white font-semibold">{item.title}</p>
                  <p className="text-[#6B6560] text-sm mt-0.5">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  )
}

// ─── Solution Section ─────────────────────────────────────────────────────────
function SolutionSection() {
  const services = [
    { icon: Globe, title: "Growth Website", desc: "Conversion-engineered sites built for performance and lead capture. Not brochures.", price: "From ₹25K" },
    { icon: Target, title: "Lead Capture System", desc: "Forms, landing pages, and follow-up sequences that work 24/7 without you.", price: "From ₹15K" },
    { icon: Zap, title: "Automation Engine", desc: "n8n workflows that handle enquiries, follow-ups, and onboarding automatically.", price: "From ₹20K" },
    { icon: LayoutDashboard, title: "CRM Dashboard", desc: "Custom Supabase-powered CRM built for your exact pipeline and workflow.", price: "From ₹30K" },
    { icon: TrendingUp, title: "Analytics System", desc: "Real-time dashboards so you know exactly what's working and what isn't.", price: "From ₹10K" },
    { icon: Sparkles, title: "Full Growth System", desc: "Everything above, built as one integrated system. The complete operating stack.", price: "From ₹75K" },
  ]

  return (
    <Section id="services" className="py-32 bg-[#F5F0E8]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">What We Build</motion.span>
            <motion.h2 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-black text-[#0F0E0C]"
              style={{ letterSpacing: "-0.03em" }}>
              Systems, not<br />
              <span className="italic text-[#C8440A]">services.</span>
            </motion.h2>
          </div>
          <motion.p variants={fadeUp} className="text-[#6B6560] max-w-xs text-sm leading-relaxed md:text-right">
            Every engagement is built as infrastructure, not a one-off deliverable.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((service, idx) => {
            const Icon = service.icon
            return (
              <motion.div key={idx} variants={fadeUp}
                className="group relative bg-white rounded-3xl p-8 border border-black/6 hover:border-[#C8440A]/20 hover:-translate-y-2 hover:shadow-xl hover:shadow-[#C8440A]/8 transition-all duration-400 cursor-default overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#C8440A]/0 to-[#C8440A]/0 group-hover:from-[#C8440A]/3 group-hover:to-transparent transition-all duration-400 rounded-3xl" />
                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-2xl bg-[#F5F0E8] group-hover:bg-[#C8440A]/10 flex items-center justify-center mb-6 transition-colors duration-300">
                    <Icon className="w-5 h-5 text-[#C8440A]" />
                  </div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-xl font-bold text-[#0F0E0C] mb-3">{service.title}</h3>
                  <p className="text-[#6B6560] text-sm leading-relaxed mb-6">{service.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-[#9E9890] bg-[#F5F0E8] px-3 py-1.5 rounded-full">{service.price}</span>
                    <ArrowUpRight className="w-4 h-4 text-[#C8440A] opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </Section>
  )
}

// ─── How It Works ─────────────────────────────────────────────────────────────
function HowItWorks() {
  const steps = [
    { num: "01", title: "Discovery Call", desc: "We spend 30 minutes understanding your business, goals, and current gaps. No templates — every brief is custom." },
    { num: "02", title: "System Blueprint", desc: "We design the exact tech stack and architecture for your needs. You get a clear plan before any work begins." },
    { num: "03", title: "Build Sprint", desc: "We build fast. Most systems are live within 2–4 weeks. Daily updates. No radio silence." },
    { num: "04", title: "Launch & Handoff", desc: "Full deployment, documentation, and a walkthrough. You own everything — code, data, and infrastructure." },
  ]

  return (
    <Section className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">The Process</motion.span>
        <motion.h2 variants={fadeUp}
          className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-black text-[#0F0E0C] mb-20"
          style={{ letterSpacing: "-0.03em" }}>
          From idea to live in <span className="italic text-[#C8440A]">weeks,</span><br />not months.
        </motion.h2>

        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, idx) => (
            <motion.div key={idx} variants={fadeUp} className="group relative">
              {idx < steps.length - 1 && (
                <div className="hidden md:block absolute top-6 left-full w-full h-px bg-gradient-to-r from-[#C8440A]/30 to-transparent z-10 -translate-x-4" />
              )}
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-2 border-[#C8440A]/30 group-hover:border-[#C8440A] group-hover:bg-[#C8440A] flex items-center justify-center mb-6 transition-all duration-300">
                  <span className="text-xs font-mono font-bold text-[#C8440A] group-hover:text-white transition-colors duration-300">{step.num}</span>
                </div>
                <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-[#0F0E0C] mb-3">{step.title}</h3>
                <p className="text-[#6B6560] text-sm leading-relaxed">{step.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  )
}

// ─── Transformation ───────────────────────────────────────────────────────────
function Transformation() {
  const items = [
    { before: "Static brochure site", after: "Conversion engine" },
    { before: "Manual lead follow-up", after: "Automated pipeline" },
    { before: "Spreadsheet CRM", after: "Real-time dashboard" },
    { before: "6-month build timeline", after: "2–4 week sprint" },
    { before: "Generic templates", after: "Custom infrastructure" },
  ]

  return (
    <Section className="py-32 bg-[#F5F0E8] relative overflow-hidden">
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full opacity-30 pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(200,68,10,0.15) 0%, transparent 70%)' }} />

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">The Transformation</motion.span>
            <motion.h2 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-black text-[#0F0E0C] mb-6"
              style={{ letterSpacing: "-0.03em" }}>
              What changes when<br />you work with <span className="italic text-[#C8440A]">Kinetic.</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-[#6B6560] leading-relaxed">
              We don&apos;t just build things. We replace what&apos;s broken with infrastructure that compounds over time.
            </motion.p>
          </div>

          <div className="space-y-3">
            {items.map((item, idx) => (
              <motion.div key={idx} variants={fadeUp}
                className="group flex items-center gap-4 bg-white rounded-2xl p-5 border border-black/5 hover:border-[#C8440A]/20 hover:shadow-md hover:shadow-[#C8440A]/5 transition-all duration-300">
                <div className="flex-1 flex items-center gap-4">
                  <span className="text-[#9E9890] text-sm line-through flex-1">{item.before}</span>
                  <ChevronRight className="w-4 h-4 text-[#C8440A] shrink-0 group-hover:translate-x-1 transition-transform" />
                  <span className="text-[#0F0E0C] font-semibold text-sm flex-1">{item.after}</span>
                </div>
                <Check className="w-4 h-4 text-[#C8440A] shrink-0" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  )
}

// ─── Portfolio ────────────────────────────────────────────────────────────────
function Portfolio() {
  return (
    <Section id="portfolio" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">Our Work</motion.span>
            <motion.h2 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-black text-[#0F0E0C]"
              style={{ letterSpacing: "-0.03em" }}>
              Built by <span className="italic text-[#C8440A]">Kinetic.</span>
            </motion.h2>
          </div>
        </div>

        {/* Featured Case Study */}
        <motion.div variants={fadeUp}
          className="group relative bg-[#0F0E0C] rounded-3xl overflow-hidden mb-6 hover:shadow-2xl hover:shadow-black/20 transition-all duration-500">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-transparent to-[#C8440A]/10 pointer-events-none" />
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
            style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`, backgroundSize: '200px' }} />

          <div className="relative z-10 p-10 md:p-14 grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block px-3 py-1.5 bg-[#C8440A]/15 text-[#C8440A] text-xs font-mono rounded-full mb-6 border border-[#C8440A]/20">FEATURED::PROJECT</span>
              <h3 className="font-[family-name:var(--font-playfair)] text-4xl font-black text-white mb-3" style={{ letterSpacing: "-0.02em" }}>Sheknowmics</h3>
              <p className="text-[#8B8580] text-sm font-mono mb-6">India&apos;s First AI-Native Women&apos;s Health Platform</p>
              <div className="flex flex-wrap gap-2 mb-8">
                {["Full-Stack Engineering", "Next.js", "AI Integration", "Supabase", "DISHA Compliant"].map(tag => (
                  <span key={tag} className="px-3 py-1 text-xs text-[#8B8580] border border-white/10 rounded-full font-mono">{tag}</span>
                ))}
              </div>
              <p className="text-[#8B8580] leading-relaxed mb-8">
                Built end-to-end — cycle intelligence, home diagnostics shop, AI health assistant, doctor consultation booking, and longitudinal health tracking. All in one privacy-first platform.
              </p>
              <div className="flex gap-8 mb-8">
                {[{ v: '1,200+', l: 'Waitlist' }, { v: 'NPS 72', l: 'Satisfaction' }, { v: '5', l: 'Modules' }].map(s => (
                  <div key={s.l}>
                    <div className="text-2xl font-black text-white font-[family-name:var(--font-playfair)]">{s.v}</div>
                    <div className="text-xs text-[#6B6560] font-mono uppercase tracking-wider">{s.l}</div>
                  </div>
                ))}
              </div>
              <a href="/work/sheknowmics"
                className="inline-flex items-center gap-2 text-white font-semibold hover:text-[#C8440A] transition-colors group/link">
                Read Case Study
                <ArrowUpRight size={16} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
              </a>
            </div>

            {/* App preview */}
            <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/30 rounded-2xl p-6 border border-white/5">
              <div className="flex gap-2 mb-5">
                <div className="w-3 h-3 rounded-full bg-red-400/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-400/60" />
                <div className="w-3 h-3 rounded-full bg-green-400/60" />
              </div>
              <div className="space-y-3">
                <div className="bg-purple-500/25 rounded-xl p-4 border border-purple-500/20">
                  <div className="text-xs font-mono text-purple-300 mb-2">🌙 LUTEAL PHASE · DAY 22 OF ~28</div>
                  <div className="flex gap-3">
                    {[['78%', 'Regularity'], ['72', 'Health'], ['0%', 'Fertility']].map(([v, l]) => (
                      <div key={l} className="bg-white/8 rounded-lg px-3 py-2 flex-1 text-center">
                        <div className="text-white text-sm font-bold">{v}</div>
                        <div className="text-purple-300/60 text-xs">{l}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                    <div className="text-xs text-[#8B8580] mb-1">🧪 PCOS Panel</div>
                    <div className="text-white text-sm font-semibold">₹2,499</div>
                  </div>
                  <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                    <div className="text-xs text-[#8B8580] mb-1">👩‍⚕️ Consult</div>
                    <div className="text-white text-sm font-semibold">Book Now</div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-pink-500/20 to-purple-500/20 rounded-xl p-3 border border-pink-500/15">
                  <div className="text-pink-300 text-xs font-mono">✦ Ask Sheknowmics AI →</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Next project placeholder */}
        <motion.div variants={fadeUp}
          className="group border-2 border-dashed border-black/10 rounded-3xl p-12 text-center hover:border-[#C8440A]/30 hover:bg-[#C8440A]/2 transition-all duration-300">
          <span className="inline-block px-3 py-1.5 bg-[#C8440A]/8 text-[#C8440A] text-xs font-mono rounded-full mb-4">NEXT::PROJECT</span>
          <h3 className="font-[family-name:var(--font-playfair)] text-2xl font-bold text-[#0F0E0C] mb-3">Your project could be here.</h3>
          <p className="text-[#6B6560] mb-6 max-w-md mx-auto text-sm">We&apos;re building our portfolio one system at a time. Want to be featured?</p>
          <a href="#contact"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0F0E0C] text-white rounded-full text-sm font-semibold hover:bg-[#C8440A] transition-colors duration-300">
            Let&apos;s Talk <ArrowUpRight size={14} />
          </a>
        </motion.div>
      </div>
    </Section>
  )
}

// ─── Tech Stack ───────────────────────────────────────────────────────────────
function TechStack() {
  const technologies = [
    { name: "Next.js", desc: "React framework" },
    { name: "Supabase", desc: "Database + auth" },
    { name: "Vercel", desc: "Edge deployment" },
    { name: "n8n", desc: "Automation engine" },
    { name: "TypeScript", desc: "Type-safe" },
    { name: "Tailwind CSS", desc: "Utility styling" },
    { name: "PostgreSQL", desc: "Database layer" },
    { name: "Framer Motion", desc: "Animations" },
  ]

  return (
    <Section className="py-24 bg-[#F5F0E8]">
      <div className="max-w-7xl mx-auto px-6">
        <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">Tech Stack</motion.span>
        <motion.h2 variants={fadeUp}
          className="font-[family-name:var(--font-playfair)] text-3xl font-black text-[#0F0E0C] mb-12"
          style={{ letterSpacing: "-0.02em" }}>
          Built on best-in-class tools.
        </motion.h2>
        <div className="flex flex-wrap gap-3">
          {technologies.map((tech, idx) => (
            <motion.div key={idx} variants={fadeUp}
              className="group flex items-center gap-3 px-5 py-3 bg-white rounded-full border border-black/6 hover:border-[#C8440A]/30 hover:bg-[#C8440A]/5 hover:-translate-y-0.5 hover:shadow-md hover:shadow-[#C8440A]/8 transition-all duration-200 cursor-default">
              <span className="font-semibold text-[#0F0E0C] text-sm">{tech.name}</span>
              <span className="text-[#9E9890] text-xs hidden group-hover:inline">— {tech.desc}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  )
}

// ─── Why Kinetic ──────────────────────────────────────────────────────────────
function WhyKinetic() {
  const reasons = [
    { num: "01", icon: Zap, title: "Systems Not Services", desc: "We build infrastructure, not deliverables. Systems that run without you." },
    { num: "02", icon: Globe, title: "India-Native Pricing", desc: "World-class engineering at pricing built for Indian founders and startups." },
    { num: "03", icon: Target, title: "You Own Everything", desc: "Code, data, infrastructure — all yours. No lock-in, no monthly hostage fees." },
    { num: "04", icon: TrendingUp, title: "Speed Without Shortcuts", desc: "2–4 week builds with no quality compromises. Fast because we're efficient, not sloppy." },
  ]

  return (
    <Section id="about" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">Why Kinetic</motion.span>
        <motion.h2 variants={fadeUp}
          className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-black text-[#0F0E0C] mb-16"
          style={{ letterSpacing: "-0.03em" }}>
          We build like we&apos;re<br /><span className="italic text-[#C8440A]">on your team.</span>
        </motion.h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reasons.map((reason, idx) => {
            const Icon = reason.icon
            return (
              <motion.div key={idx} variants={fadeUp}
                className="group p-8 rounded-3xl border border-black/6 hover:border-[#C8440A]/20 hover:bg-[#C8440A]/3 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#C8440A]/6 transition-all duration-300 cursor-default">
                <div className="flex items-center justify-between mb-6">
                  <span className="text-xs font-mono text-[#9E9890]">{reason.num}</span>
                  <div className="w-10 h-10 rounded-xl bg-[#F5F0E8] group-hover:bg-[#C8440A]/10 flex items-center justify-center transition-colors duration-300">
                    <Icon className="w-4 h-4 text-[#C8440A]" />
                  </div>
                </div>
                <h3 className="font-[family-name:var(--font-playfair)] font-bold text-[#0F0E0C] mb-3">{reason.title}</h3>
                <p className="text-[#6B6560] text-sm leading-relaxed">{reason.desc}</p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </Section>
  )
}

// ─── CTA Section ──────────────────────────────────────────────────────────────
function CTASection() {
  return (
    <Section className="py-32 bg-[#0F0E0C] relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`, backgroundSize: '200px' }} />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, rgba(200,68,10,0.15) 0%, transparent 70%)' }} />
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-6">Ready to Build?</motion.span>
        <motion.h2 variants={fadeUp}
          className="font-[family-name:var(--font-playfair)] text-5xl md:text-6xl lg:text-7xl font-black text-white mb-8"
          style={{ letterSpacing: "-0.04em", lineHeight: 0.92 }}>
          Stop leaving<br />
          growth on the<br />
          <span className="italic text-[#C8440A]">table.</span>
        </motion.h2>
        <motion.p variants={fadeUp} className="text-[#6B6560] text-lg mb-12 max-w-xl mx-auto">
          Every week without a proper system is revenue you&apos;re not capturing. Let&apos;s change that.
        </motion.p>
        <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
          <MagneticButton href="#contact"
            className="group flex items-center justify-center gap-3 px-10 py-5 bg-[#C8440A] text-white font-bold rounded-full hover:bg-[#D4550B] transition-all duration-300 shadow-xl shadow-[#C8440A]/30 hover:shadow-[#C8440A]/50 text-lg">
            Start Your Project
            <ArrowUpRight size={18} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </MagneticButton>
        </motion.div>
      </div>
    </Section>
  )
}

// ─── Contact Form ─────────────────────────────────────────────────────────────
function ContactForm() {
  const [formData, setFormData] = useState({ name: "", phone: "", email: "", service: "", message: "" })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name, email: formData.email,
          phone: formData.phone, company: formData.service, message: formData.message,
        }),
      })
      const data = await res.json()
      if (res.ok && data.success) {
        setSuccess(true)
        setFormData({ name: "", phone: "", email: "", service: "", message: "" })
      } else {
        setError(data.error || "Something went wrong. Please try again.")
      }
    } catch { setError("Network error. Please try again.") }
    setLoading(false)
  }

  const inputClass = "w-full px-5 py-4 bg-[#F5F0E8] border border-black/8 rounded-2xl text-[#0F0E0C] placeholder:text-[#9E9890] focus:outline-none focus:border-[#C8440A]/40 focus:bg-white transition-all duration-200 text-sm"

  return (
    <Section id="contact" className="py-32 bg-[#F5F0E8]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <motion.span variants={fadeUp} className="text-xs font-mono text-[#C8440A] tracking-[0.2em] uppercase block mb-4">Get In Touch</motion.span>
            <motion.h2 variants={fadeUp}
              className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-black text-[#0F0E0C] mb-6"
              style={{ letterSpacing: "-0.03em" }}>
              Let&apos;s build<br /><span className="italic text-[#C8440A]">together.</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-[#6B6560] mb-12 leading-relaxed">
              Tell us about your project. We&apos;ll review it and get back within 24 hours with a clear plan.
            </motion.p>

            {success && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
                className="mb-6 px-5 py-4 rounded-2xl bg-green-50 border border-green-200 text-green-700 text-sm flex items-center gap-2">
                <Check className="w-4 h-4" />
                Message received! We&apos;ll be in touch within 24 hours.
              </motion.div>
            )}
            {error && (
              <div className="mb-6 px-5 py-4 rounded-2xl bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
            )}

            <motion.form variants={stagger} onSubmit={handleSubmit} className="space-y-4">
              <motion.div variants={fadeUp}>
                <label className="block text-xs font-mono text-[#6B6560] uppercase tracking-wider mb-2">Full Name *</label>
                <input required type="text" value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className={inputClass} placeholder="Your name" />
              </motion.div>

              <motion.div variants={fadeUp} className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-[#6B6560] uppercase tracking-wider mb-2">Phone</label>
                  <input type="tel" value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className={inputClass} placeholder="+91 98765 43210" />
                </div>
                <div>
                  <label className="block text-xs font-mono text-[#6B6560] uppercase tracking-wider mb-2">Email *</label>
                  <input required type="email" value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className={inputClass} placeholder="your@email.com" />
                </div>
              </motion.div>

              <motion.div variants={fadeUp}>
                <label className="block text-xs font-mono text-[#6B6560] uppercase tracking-wider mb-2">Service</label>
                <select value={formData.service} onChange={e => setFormData({ ...formData, service: e.target.value })} className={inputClass}>
                  <option value="">Select a service</option>
                  <option value="Growth Website">Growth Website</option>
                  <option value="Lead Capture System">Lead Capture System</option>
                  <option value="Automation Engine">Automation Engine</option>
                  <option value="CRM Dashboard">CRM Dashboard</option>
                  <option value="Full Growth System">Full Growth System</option>
                </select>
              </motion.div>

              <motion.div variants={fadeUp}>
                <label className="block text-xs font-mono text-[#6B6560] uppercase tracking-wider mb-2">Message</label>
                <textarea value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })}
                  rows={4} className={inputClass + " resize-none"} placeholder="Tell us about your project..." />
              </motion.div>

              <motion.div variants={fadeUp}>
                <button type="submit" disabled={loading || success}
                  className="w-full px-8 py-4 bg-[#0F0E0C] text-white font-semibold rounded-2xl hover:bg-[#C8440A] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-black/10 hover:shadow-[#C8440A]/20 text-sm">
                  {loading ? "Sending..." : success ? "✓ Sent!" : "Send Message →"}
                </button>
              </motion.div>
            </motion.form>
          </div>

          <motion.div variants={fadeUp} className="lg:pt-20">
            <div className="bg-white rounded-3xl p-10 border border-black/6 shadow-sm h-fit">
              <h3 className="font-[family-name:var(--font-playfair)] text-2xl font-bold text-[#0F0E0C] mb-8">Contact Details</h3>
              <div className="space-y-6 mb-10">
                <div className="flex items-start gap-4 group">
                  <div className="w-10 h-10 rounded-xl bg-[#F5F0E8] group-hover:bg-[#C8440A]/10 flex items-center justify-center transition-colors">
                    <Mail className="w-4 h-4 text-[#C8440A]" />
                  </div>
                  <div>
                    <p className="text-xs font-mono text-[#9E9890] uppercase tracking-wider mb-1">Email</p>
                    <a href="mailto:hello@buildwithkinetic.org" className="text-[#0F0E0C] hover:text-[#C8440A] transition-colors font-medium">
                      hello@buildwithkinetic.org
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4 group">
                  <div className="w-10 h-10 rounded-xl bg-[#F5F0E8] group-hover:bg-[#C8440A]/10 flex items-center justify-center transition-colors">
                    <MapPin className="w-4 h-4 text-[#C8440A]" />
                  </div>
                  <div>
                    <p className="text-xs font-mono text-[#9E9890] uppercase tracking-wider mb-1">Location</p>
                    <p className="text-[#0F0E0C] font-medium">India</p>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-black/6">
                <p className="text-xs font-mono text-[#9E9890] uppercase tracking-wider mb-2">Response Time</p>
                <p className="font-[family-name:var(--font-playfair)] text-4xl font-black text-[#0F0E0C]">{"< 24"}<span className="text-[#C8440A]">h</span></p>
              </div>

              <div className="mt-8 p-5 bg-[#F5F0E8] rounded-2xl">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs font-mono text-[#6B6560] uppercase tracking-wider">Currently Accepting</span>
                </div>
                <p className="text-sm text-[#0F0E0C] font-medium">New client projects for Q2 2026</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </Section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="bg-[#0F0E0C] py-16 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-start justify-between gap-10 mb-12">
          <div>
            <a href="#" className="font-[family-name:var(--font-playfair)] text-2xl font-black text-white">
              KINETIC<span className="text-[#C8440A]">.</span>
            </a>
            <p className="text-[#6B6560] text-sm mt-2 font-light">Digital Growth Infrastructure</p>
          </div>
          <div className="grid grid-cols-2 gap-x-16 gap-y-3">
            {[["Services", "#services"], ["Portfolio", "#portfolio"], ["About", "#about"], ["Contact", "#contact"]].map(([label, href]) => (
              <a key={label} href={href}
                className="text-sm text-[#6B6560] hover:text-white transition-colors duration-200 relative group w-fit">
                {label}
                <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-[#C8440A] group-hover:w-full transition-all duration-300" />
              </a>
            ))}
          </div>
        </div>
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-mono text-[#3A3835] text-xs">© 2026 Kinetic // All Systems Operational</p>
          <p className="text-[#3A3835] text-xs font-mono">buildwithkinetic.org</p>
        </div>
      </div>
    </footer>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function KineticPage() {
  return (
    <main className="min-h-screen bg-[#F5F0E8] text-[#0F0E0C] overflow-x-hidden">
      <Navbar />
      <Hero />
      <ProblemSection />
      <SolutionSection />
      <HowItWorks />
      <Transformation />
      <Portfolio />
      <TechStack />
      <WhyKinetic />
      <CTASection />
      <ContactForm />
      <Footer />
    </main>
  )
}