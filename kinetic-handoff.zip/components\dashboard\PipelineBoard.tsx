export const PipelineBoard = () => null

