export const Badge = () => null

