export const LeadTable = () => null

