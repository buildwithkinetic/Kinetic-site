import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Sheknowmics Case Study — Kinetic',
  description: "How Kinetic engineered India's first AI-native women's health platform end to end.",
}

export default function SheknowmicsCaseStudy() {
  return (
    <main className="bg-[#080A0F] min-h-screen text-[#F8FAFC]">

      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#080A0F]/80 backdrop-blur-xl border-b border-[#F97316]/10">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-xl font-black tracking-tight">
            KINETIC<span className="text-[#F97316]">.</span>
          </Link>
          <Link href="/#contact"
            className="px-4 py-2 bg-[#F97316] text-black font-bold rounded-full text-sm hover:bg-[#F97316]/90 transition-colors">
            Work With Us
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Link href="/" className="text-[#64748B] text-sm font-mono hover:text-[#F97316] transition-colors">HOME</Link>
            <span className="text-[#1E293B]">/</span>
            <span className="text-[#64748B] text-sm font-mono">WORK</span>
            <span className="text-[#1E293B]">/</span>
            <span className="text-[#F97316] text-sm font-mono">SHEKNOWMICS</span>
          </div>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-2xl">
              🩺
            </div>
            <div>
              <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-1">Case Study</p>
              <h1 className="text-4xl md:text-5xl font-black tracking-tight">Sheknowmics</h1>
            </div>
          </div>

          <p className="text-xl text-[#94A3B8] leading-relaxed max-w-2xl mb-10">
            Engineering India&apos;s first AI-native women&apos;s health platform — from zero to a full-stack product with cycle intelligence, home diagnostics, AI risk prediction, and doctor consultations.
          </p>

          <div className="flex flex-wrap gap-3">
            {['Full Stack Engineering', 'Next.js', 'React', 'Supabase', 'AI Integration', 'Product Architecture'].map(tag => (
              <span key={tag} className="px-3 py-1.5 bg-[#111318] border border-[#1E293B] rounded-full text-xs font-mono text-[#94A3B8]">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 px-6 border-y border-[#1E293B]/50">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '1,200+', label: 'Waitlist Users', sub: 'Organic, zero paid ads' },
            { value: 'NPS 72', label: 'User Satisfaction', sub: 'Pilot cohort' },
            { value: '5', label: 'Core Modules', sub: 'Built end to end' },
            { value: '48hr', label: 'Lab Turnaround', sub: 'For diagnostics' },
          ].map(stat => (
            <div key={stat.label} className="bg-[#111318] rounded-2xl p-5 border border-[#1E293B]/50">
              <div className="text-3xl font-black text-[#F97316] mb-1">{stat.value}</div>
              <div className="text-sm font-semibold text-[#F8FAFC]">{stat.label}</div>
              <div className="text-xs text-[#64748B] mt-0.5">{stat.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* The Brief */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-4">THE BRIEF</p>
          <h2 className="text-3xl font-black mb-6">The problem worth solving</h2>
          <div className="grid md:grid-cols-3 gap-4 mb-10">
            {[
              { stat: '1 in 5', desc: 'Indian women have PCOS' },
              { stat: '6+ yrs', desc: 'Average diagnosis delay for hormonal conditions' },
              { stat: '80%', desc: 'Of tests are clinical or invasive — causing stigma' },
            ].map(item => (
              <div key={item.stat} className="bg-[#111318] rounded-2xl p-6 border border-[#F97316]/10">
                <div className="text-4xl font-black text-[#F97316] mb-2">{item.stat}</div>
                <p className="text-[#94A3B8] text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
          <p className="text-[#94A3B8] text-lg leading-relaxed">
            Sheknowmics came to Kinetic with a bold vision — build India&apos;s first full-stack women&apos;s health OS that combines non-invasive home diagnostics, AI-powered cycle intelligence, and personalised care in a single platform. No such product existed. We were brought in to architect and build the entire product from scratch.
          </p>
        </div>
      </section>

      {/* What We Built */}
      <section className="py-20 px-6 bg-[#111318]/50">
        <div className="max-w-4xl mx-auto">
          <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-4">WHAT WE BUILT</p>
          <h2 className="text-3xl font-black mb-10">Five modules. One platform.</h2>

          <div className="space-y-4">
            {[
              {
                icon: '🌙',
                title: 'Cycle Intelligence Dashboard',
                desc: 'Real-time cycle phase tracking (Luteal, Follicular, Ovulatory, Menstrual) with hormone level visualisation — Estrogen, Progesterone, LH, FSH — health score, regularity index, and fertility window prediction.',
                tags: ['React', 'Data Visualisation', 'AI'],
              },
              {
                icon: '🧪',
                title: 'Home Diagnostics Shop',
                desc: 'End-to-end e-commerce for CDSCO/CE/FDA/IVD approved at-home test kits — PCOS Panel, CerviArogya HPV DNA, Period Blood Panel, and Hormobalance. Order management, discreet delivery, and 48hr lab TAT.',
                tags: ['E-commerce', 'Order Management', 'Supabase'],
              },
              {
                icon: '👩‍⚕️',
                title: 'Doctor Consultation Booking',
                desc: 'Full telemedicine and in-clinic appointment booking with specialty filtering (Gynaecology, Reproductive Endocrinology), doctor profiles, ratings, and 100% confidential consultation guarantee.',
                tags: ['Booking System', 'Real-time', 'Privacy'],
              },
              {
                icon: '📚',
                title: 'Learn & AI Assistant',
                desc: 'Daily personalised health insights, expert reads, and the Sheknowmics AI — a conversational health assistant trained to answer questions about cycles, PCOS, fertility, and more.',
                tags: ['AI Integration', 'Content Engine', 'Personalisation'],
              },
              {
                icon: '👤',
                title: 'User Profile & Health Summary',
                desc: 'Longitudinal health tracking with cycle summary, test history, notification management, DISHA-compliant privacy controls, and multi-language support.',
                tags: ['DISHA Compliance', 'Encryption', 'i18n'],
              },
            ].map((module, idx) => (
              <div key={module.title} className="bg-[#111318] rounded-2xl p-6 border border-[#1E293B]/50 hover:border-[#F97316]/20 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#F97316]/10 flex items-center justify-center text-xl shrink-0">
                    {module.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-mono text-[#F97316]">0{idx + 1}</span>
                      <h3 className="font-bold text-[#F8FAFC]">{module.title}</h3>
                    </div>
                    <p className="text-[#94A3B8] text-sm leading-relaxed mb-3">{module.desc}</p>
                    <div className="flex flex-wrap gap-2">
                      {module.tags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 bg-[#080A0F] rounded-full text-xs font-mono text-[#64748B] border border-[#1E293B]">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-4">TECH STACK</p>
          <h2 className="text-3xl font-black mb-10">Built to scale from day one</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { layer: 'Frontend', tech: 'Next.js 14, React, Tailwind CSS' },
              { layer: 'Backend', tech: 'Supabase, PostgreSQL, Row Level Security' },
              { layer: 'AI Layer', tech: 'Custom AI assistant, Personalisation engine' },
              { layer: 'Compliance', tech: 'DISHA-compliant, Encrypted at rest' },
            ].map(item => (
              <div key={item.layer} className="bg-[#111318] rounded-2xl p-5 border border-[#1E293B]/50">
                <p className="text-xs font-mono text-[#F97316] mb-2 uppercase tracking-wider">{item.layer}</p>
                <p className="text-sm text-[#94A3B8]">{item.tech}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Outcome */}
      <section className="py-20 px-6 bg-[#111318]/50">
        <div className="max-w-4xl mx-auto">
          <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-4">THE OUTCOME</p>
          <h2 className="text-3xl font-black mb-6">Pre-launch. Already gaining traction.</h2>
          <p className="text-[#94A3B8] text-lg leading-relaxed mb-10">
            Sheknowmics launched with a complete, production-ready platform that no competitor in India has fully replicated. With 1,200+ waitlist signups acquired organically and an NPS of 72 from its pilot cohort, the platform is primed for its public launch.
          </p>
          <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-8">
            <p className="text-xs font-mono text-purple-400 tracking-widest uppercase mb-3">WHAT MAKES IT UNIQUE</p>
            <p className="text-[#F8FAFC] text-lg leading-relaxed">
              Sheknowmics is the only platform in India that combines consumer cycle tracking, molecular diagnostics, AI risk prediction, and telemedicine in a single privacy-first product. We didn&apos;t just build an app — we built the infrastructure for a new category.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xs font-mono text-[#F97316] tracking-widest uppercase mb-4">READY TO BUILD?</p>
          <h2 className="text-4xl font-black mb-6">Have a product that needs engineering?</h2>
          <p className="text-[#94A3B8] text-lg mb-8">We build full-stack digital products end to end — from architecture to deployment.</p>
          <Link href="/#contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#F97316] text-black font-bold rounded-full text-lg hover:bg-[#F97316]/90 transition-colors">
            Start a Project →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-[#1E293B]/50 text-center">
        <p className="text-xs font-mono text-[#1E293B]">© 2026 KINETIC // BUILDWITHKINETIC.ORG</p>
      </footer>

    </main>
  )
}