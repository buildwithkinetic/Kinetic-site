export const Footer = () => null

