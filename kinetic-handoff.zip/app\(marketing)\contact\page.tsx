"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Loader2, CheckCircle } from "lucide-react"

export default function ContactPage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [company, setCompany] = useState("")
  const [message, setMessage] = useState("")

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, company, message }),
      })

      const data = await res.json()

      if (res.ok && data.success) {
        setSuccess(true)
      } else {
        setError(data.error || "Something went wrong. Please try again.")
      }
    } catch (err) {
      setError("Network error. Please try again.")
    }

    setLoading(false)
  }

  if (success) {
    return (
      <main className="min-h-screen bg-[#080A0F] flex items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-md"
        >
          <CheckCircle size={56} className="text-[#F97316] mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-3" style={{ fontFamily: "'Syne', sans-serif" }}>
            Message Received
          </h2>
          <p className="text-white/40 mb-8">
            Thanks <span className="text-white">{name}</span>. We&apos;ll be in touch within 24 hours.
          </p>
          <a href="/" className="text-[#F97316] hover:underline text-sm">← Back to home</a>
        </motion.div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#080A0F] py-24 px-6 relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(rgba(249,115,22,0.06) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      <div className="relative z-10 max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className="font-mono text-xs text-[#F97316] tracking-widest uppercase mb-4">
            CONTACT::KINETIC
          </p>
          <h1
            className="text-5xl font-black text-white leading-none mb-4"
            style={{ fontFamily: "'Syne', sans-serif" }}
          >
            Let&apos;s Build<br />
            <span className="text-[#F97316]">Your System.</span>
          </h1>
          <p className="text-white/40 text-lg mb-12">
            Tell us about your business. We&apos;ll design the system.
          </p>

          {error && (
            <div className="mb-6 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm font-mono">
              ERROR:: {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-mono text-xs text-white/30 tracking-widest uppercase mb-2">Name *</label>
                <input
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full bg-white/[0.03] border border-[#F97316]/20 rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm focus:outline-none focus:border-[#F97316]/50 transition-all"
                />
              </div>
              <div>
                <label className="block font-mono text-xs text-white/30 tracking-widest uppercase mb-2">Company</label>
                <input
                  value={company}
                  onChange={e => setCompany(e.target.value)}
                  placeholder="Acme Corp"
                  className="w-full bg-white/[0.03] border border-[#F97316]/20 rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm focus:outline-none focus:border-[#F97316]/50 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-mono text-xs text-white/30 tracking-widest uppercase mb-2">Email *</label>
                <input
                  required
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="john@company.com"
                  className="w-full bg-white/[0.03] border border-[#F97316]/20 rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm focus:outline-none focus:border-[#F97316]/50 transition-all"
                />
              </div>
              <div>
                <label className="block font-mono text-xs text-white/30 tracking-widest uppercase mb-2">Phone</label>
                <input
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-white/[0.03] border border-[#F97316]/20 rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm focus:outline-none focus:border-[#F97316]/50 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block font-mono text-xs text-white/30 tracking-widest uppercase mb-2">Message *</label>
              <textarea
                required
                value={message}
                onChange={e => setMessage(e.target.value)}
                rows={5}
                placeholder="Tell us about your business and what you need..."
                className="w-full bg-white/[0.03] border border-[#F97316]/20 rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm focus:outline-none focus:border-[#F97316]/50 transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#F97316] text-black font-bold py-4 rounded-xl hover:bg-[#F97316]/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <><Loader2 size={18} className="animate-spin" /> Sending...</>
              ) : (
                "Send Message"
              )}
            </button>
          </form>

          <p className="text-center font-mono text-xs text-white/10 mt-8">
            hello@kinetic.systems · Response within 24h
          </p>
        </motion.div>
      </div>
    </main>
  )
}