export const Hero = () => null

